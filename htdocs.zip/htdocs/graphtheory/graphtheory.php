<html>
    <head>
        <link rel="stylesheet" href="../index.css">
        <script id="MathJax-script" async src="../mathjax/tex-chtml.js"></script>
    </head>

    <body>
        <div class="page">
            <h1>Graph Theory</h1>

            <?php
                $db = "graphtheory";
                require "../utility.php";
                
                $sql = "SELECT ncontent FROM daily_notes";
                $result = $conn->query($sql);
                
                if($result->num_rows > 0) {
                    echo $parsedown->text($result->fetch_assoc()["ncontent"]);

//                     while($row = $result->fetch_assoc()) {
//                         echo $row["ncontent"];
//                     }
                } else {
                    echo "No data";
                }
            ?>
            
        </div>
    </body>
</html>
