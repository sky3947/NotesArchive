[{"locale":"fr"},{"key":"s","mappings":{"default":{"default":"secondes","singular":"seconde","dual":""}},"category":"time","names":["s"]}]
