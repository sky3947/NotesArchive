<?php
    $conn = mysqli_connect("localhost", "root", "sky3947@rit.edu", $db);
?>