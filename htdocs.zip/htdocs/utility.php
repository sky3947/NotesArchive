<?php
    require "dbconnect.php";
    require "Parsedown.php";
    require "ParsedownExtended.php";

    if($conn->connect_error) {
        die("Connection failed: ".$conn->connect_error);
    }

    $parsedown = new ParsedownExtended([
        "math" => true,
    ]);
?>