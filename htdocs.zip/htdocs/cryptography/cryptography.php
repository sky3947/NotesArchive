<?php $db = "cryptography"; require "../utility.php";?>

<html>
    <head>
        <link rel="stylesheet" href="../index.css">
        <script id="MathJax-script" async src="../mathjax/tex-chtml.js"></script>
    </head>

    <body>
        <div class="page">
            <h1>Introduction to Cryptography</h1><br>
            
            <div class="block">
                <h3>Daily Notes</h3>

                <?php
                    $sql = "SELECT date FROM daily_notes";
                    $result = $conn->query($sql);

                    if($result->num_rows > 0) {
                        while($row = $result->fetch_assoc()) {
                            ?><a href="notes.php?id=<?php echo $row['date'];?>"><?php echo $row['date']; ?></a><br><?php
                        }
                    } else {
                        echo "No data";
                    }
                ?>

            </div>
            
        </div>
    </body>
</html>
