<?php $db = "cryptography"; require "../utility.php";?>

<?php
    $date = $_GET["id"];

    if (!preg_match("/^[0-9]{4}-(0[1-9]|1[0-2])-(0[1-9]|[1-2][0-9]|3[0-1])$/",$date)) {
        include "../404.php";
        exit;
    }

    $sql = "SELECT ncontent FROM daily_notes where date = '$date'";
    $result = $conn->query($sql);
?>

<html>
    <head>
        <link rel="stylesheet" href="../index.css">
        <script id="MathJax-script" async src="../mathjax/tex-chtml.js"></script>
    </head>

    <body>
        <div class="page">
            <h1><?php echo $date;?> Notes</h1><br>
            
            <div class="block">
                <?php
                    if($result->num_rows > 0) {
                        echo $parsedown->text($result->fetch_assoc()["ncontent"]);
                    } else {
                        echo "No result";
                    }
                ?>
            </div>

            <div>
                <div class="conceptsheader">
                    <h3>List of concepts</h3>
                </div>
                <div class="conceptsbody">
                    <?php
                        $sql = "SELECT concept FROM cover where date = '$date'";
                        $result = $conn->query($sql);

                        if($result->num_rows == 1) {
                            $row = $result->fetch_assoc()
                            ?><a href="concepts.php?id=<?php echo $row['concept'];?>"><?php echo $row['concept']; ?></a><?php
                        } else {
                            $row = $result->fetch_assoc()
                            ?><a href="concepts.php?id=<?php echo $row['concept'];?>"><?php echo $row['concept']; ?></a><?php
                            while($row = $result->fetch_assoc()) {
                                ?> · <a href="concepts.php?id=<?php echo $row['concept'];?>"><?php echo $row['concept']; ?></a><?php
                            }
                        }
                    ?>
                </div>
            </div>
            
        </div>
    </body>
</html>
