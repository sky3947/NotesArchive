<?php $db = "cryptography"; require "../utility.php";?>

<?php
    $concept = $_GET["id"];

    $sql = "SELECT ccontent FROM concepts where concept = '$concept'";
    $result = $conn->query($sql);

    if($result->num_rows == 0) {
        include "../404.php";
        exit;
    }
?>

<html>
    <head>
        <link rel="stylesheet" href="../index.css">
        <script id="MathJax-script" async src="../mathjax/tex-chtml.js"></script>
    </head>

    <body>
        <div class="page">
            <h1><?php echo $concept;?></h1><br>
            
            <div class="block">
                <?php
                    echo $parsedown->text($result->fetch_assoc()["ccontent"]);
                ?>
            </div>

            <div>
                <div class="conceptsheader">
                    <h3>Appearances in notes</h3>
                </div>
                <div class="conceptsbody">
                    <?php
                        $sql = "SELECT date FROM cover where concept = '$concept'";
                        $result = $conn->query($sql);

                        if($result->num_rows == 1) {
                            $row = $result->fetch_assoc()
                            ?><a href="notes.php?id=<?php echo $row['date'];?>"><?php echo $row['date']; ?></a><?php
                        } else {
                            $row = $result->fetch_assoc()
                            ?><a href="notes.php?id=<?php echo $row['date'];?>"><?php echo $row['date']; ?></a><?php
                            while($row = $result->fetch_assoc()) {
                                ?> · <a href="notes.php?id=<?php echo $row['date'];?>"><?php echo $row['date']; ?></a><?php
                            }
                        }
                    ?>
                </div>
            </div>
            
        </div>
    </body>
</html>
