<html>
    <head>
        <link rel="stylesheet" href="../index.css">
    </head>

    <body>
        <div class="page">
            <h1>404 Error</h1>
            <p>Oops! This link is invalid.</p>
        </div>
    </body>
</html>
